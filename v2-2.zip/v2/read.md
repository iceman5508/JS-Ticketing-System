ugly first form of all javascript application
